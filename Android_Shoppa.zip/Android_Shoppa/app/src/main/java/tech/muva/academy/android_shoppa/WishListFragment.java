package tech.muva.academy.android_shoppa;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import io.objectbox.Box;


/**
 * A simple {@link Fragment} subclass.
 */
public class WishListFragment extends Fragment {


    public WishListFragment() {
        // Required empty public constructor
    }
    private WishListRecyclerAdapter mWishListRecyclerAdapter;
    private ArrayList<Testproduct> mArrayList = new ArrayList<>();
    private List<Testproduct> allproducts = new ArrayList<>();
    private Box<Testproduct> mTestproductBox;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_wish_list, container, false);
        RecyclerView recyclerView = view.findViewById(R.id.wishlist_recyclerview);
        mWishListRecyclerAdapter = new WishListRecyclerAdapter(getActivity(), mArrayList);
        populateRecyclerView();
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(mWishListRecyclerAdapter);

        return view;
    }

    private void populateRecyclerView() {
        mTestproductBox = ObjectBox.get().boxFor(Testproduct.class);
        //allproducts.clear();
        allproducts= mTestproductBox.query()
                .order(Testproduct_.__ID_PROPERTY).build().find();
        mArrayList.clear();
        mArrayList.addAll(allproducts);
        mWishListRecyclerAdapter.notifyDataSetChanged();
    }

}
