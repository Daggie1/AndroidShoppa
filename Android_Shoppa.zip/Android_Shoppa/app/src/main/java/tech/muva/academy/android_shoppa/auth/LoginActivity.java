package tech.muva.academy.android_shoppa.auth;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import tech.muva.academy.android_shoppa.ProductActivity;
import tech.muva.academy.android_shoppa.R;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    Button buttonLogin;
    TextView redirectRegister, redirectForgotPassword;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        buttonLogin = findViewById(R.id.button_login);
        redirectForgotPassword =findViewById(R.id.redirect_forgot_password);
        redirectRegister = findViewById(R.id.redirect_register);

        buttonLogin.setOnClickListener(this);
        redirectRegister.setOnClickListener(this);
        redirectForgotPassword.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
        int id = view.getId();

        if (id == R.id.button_login) {
            Intent intent = new Intent(this, ProductActivity.class);
            startActivity(intent);
            Toast.makeText(this,"Welcome To Shoppy",Toast.LENGTH_SHORT).show();
        }
        else if (id == R.id.redirect_register){
            Intent in = new Intent(this, RegisterActivity.class);
            startActivity(in);
//            Intent intent=  ResetPasswordActivity.startSelfIntent(this,true);
//            startActivity(intent);
        }
        else if (id == R.id.redirect_forgot_password){
          Intent intent=  ResetPasswordActivity.startSelfIntent(this,false);
            startActivity(intent);
        }
    }
}
