package tech.muva.academy.android_shoppa;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.List;

import io.objectbox.Box;


public class TabLayoutAdapter extends FragmentPagerAdapter
{
//    String[] categories = {"Category A", "Category B","Category C","Category D",
//            "Category E","Category F","Category G","Category H"};
    Box<Testproduct> mTestproductBox = ObjectBox.get().boxFor(Testproduct.class);
    List<Testproduct> categories = mTestproductBox.query()
            .order(Testproduct_.__ID_PROPERTY).build().find();
    int number_of_categories = categories.size();
    public TabLayoutAdapter(@NonNull FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {

        if (number_of_categories != 0){
            for (int index = 0; index< number_of_categories;index++  )
            {
                return ElectronicsFragment.newInstance(position);
            }
        }
        else
            return null;


        return null;
    }


    @Override
    public int getCount() {
        return number_of_categories;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {


        if(number_of_categories != 0){
              return categories.get(position).category;
        }
        return null;
    }
}


