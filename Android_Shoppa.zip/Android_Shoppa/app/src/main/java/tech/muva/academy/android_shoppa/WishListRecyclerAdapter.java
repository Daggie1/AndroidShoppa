package tech.muva.academy.android_shoppa;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class WishListRecyclerAdapter extends RecyclerView.Adapter<WishListRecyclerAdapter.ViewHolder> {
    private Context mContext;
    private ArrayList<Testproduct> mArrayList;
    private LayoutInflater mInflater;

    public WishListRecyclerAdapter(Context context,ArrayList<Testproduct> arrayList){
        mArrayList = arrayList;
        mContext = context;
    }
    @NonNull
    @Override
    public WishListRecyclerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_wishlist, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Testproduct testproduct = mArrayList.get(position);
        holder.productname.setText(testproduct.getName());
        holder.productprice.setText(testproduct.getPrice());
        holder.productimage.setImageResource(testproduct.getImage());
        holder.cart_icon.setImageResource(R.drawable.cart);
    }

    @Override
    public int getItemCount() {
        return mArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView productname, productprice;
        CircleImageView productimage;
        ImageView cart_icon;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            productname = itemView.findViewById(R.id.wishlist_product_name);
            productprice = itemView.findViewById(R.id.wishlist_product_price);
            productimage = itemView.findViewById(R.id.wishlist_product_image);
            cart_icon = itemView.findViewById(R.id.wishlist_cart_icon);
        }
    }
}
