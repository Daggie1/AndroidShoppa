package tech.muva.academy.android_shoppa;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import io.objectbox.Box;


/**
 * A simple {@link Fragment} subclass.
 */
public class ElectronicsFragment extends Fragment {


    public ElectronicsFragment() {
        // Required empty public constructor
    }
    private Box<Testproduct> mTestproductBox;


    public static ArrayList<Testproduct> mArraylist = new ArrayList<>();
    private MyRecyclerViewAdapter mMyRecyclerViewAdapter;
    int val;
    private List<Testproduct> allproducts =new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_electronics,container,false);
        RecyclerView recyclerView = view.findViewById(R.id.electronics_recycler_view);
        mMyRecyclerViewAdapter = new MyRecyclerViewAdapter(getActivity(),mArraylist);
        populateRecyclerView();

        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(),2));
        recyclerView.setAdapter(mMyRecyclerViewAdapter);

        TextView fragment_number = view.findViewById(R.id.fragment_number);
        val = getArguments().getInt("someInt",0);
        fragment_number.setText(" "+val);

        //fragment_number.setText(categories.get(val).category);
        return view;

    }
    public static ElectronicsFragment newInstance(int val) {
        ElectronicsFragment fragment = new ElectronicsFragment ();
        Bundle args = new Bundle();
        args.putInt("someInt", val);
        fragment.setArguments(args);
        return fragment;
    }

    private void populateRecyclerView() {
        mTestproductBox = ObjectBox.get().boxFor(Testproduct.class);
        //allproducts.clear();
        allproducts= mTestproductBox.query()
                .order(Testproduct_.__ID_PROPERTY).build().find();
        mArraylist.clear();
        mArraylist.addAll(allproducts);
        mMyRecyclerViewAdapter.notifyDataSetChanged();
    }

}

