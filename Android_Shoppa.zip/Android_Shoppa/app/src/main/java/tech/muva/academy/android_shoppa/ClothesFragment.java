package tech.muva.academy.android_shoppa;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class ClothesFragment extends Fragment {


    public ClothesFragment() {
        // Required empty public constructor
    }
    private String[] productNames = {"Cape","Natural light googles","Black Lether Wallet",
            "Nike supra 3","Denim Shirt","Khaki handbags","Brown Rubber"
    };
    private String[] productDescription = {"Cape","Natural light googles","Black Lether Wallet",
            "Nike supra 3","Denim Shirt","Khaki handbags","Brown Rubber"
    };
    private int[] productImages = {R.drawable.cape,R.drawable.googles,R.drawable.wallet,
            R.drawable.nike,R.drawable.denimshirt,R.drawable.h_bag,R.drawable.rubber_shoe};

    private String[] productPrices = {"17000","800","1500","3500","1500","1200","2200"};

    private int cart_icon = R.drawable.ic_cart;
    private int wishlist_icon = R.drawable.ic_heart;
    private ArrayList<Product> mArraylist = new ArrayList<>();
    private MyRecyclerViewAdapter mMyRecyclerViewAdapter ;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_clothes, container,false);
//        RecyclerView recyclerView = view.findViewById(R.id.clothes_recycler_view);
//        mMyRecyclerViewAdapter=new MyRecyclerViewAdapter(getActivity(),mArraylist);
//        PopulateRecyclerView populateRecyclerView =
//                new PopulateRecyclerView(productNames, productPrices,
//                        productImages,productDescription, cart_icon, wishlist_icon, mArraylist, mMyRecyclerViewAdapter);
//        populateRecyclerView.populate();
//
//        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 2));
//        recyclerView.setAdapter(mMyRecyclerViewAdapter);
        return view;
    }

}

