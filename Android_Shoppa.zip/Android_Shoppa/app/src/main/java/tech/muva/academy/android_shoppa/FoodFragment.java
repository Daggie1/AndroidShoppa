package tech.muva.academy.android_shoppa;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class FoodFragment extends Fragment {


    public FoodFragment() {
        // Required empty public constructor
    }

    private String[] productNames = {"Githeri","burger","Cinamon Toast",
            "fries","Meat","Milk","Chocolate"
    };
    private String[] productDescription = {"Githeri","burger","Cinamon Toast",
            "fries","Meat","Milk","Chocolate"
    };
    private int[] productImages = {R.drawable.githeri,R.drawable.burger,R.drawable.cinamon_toast,
            R.drawable.fries,R.drawable.meat,R.drawable.milk,R.drawable.chocolate};

    private String[] productPrices = {"17000","800","1500","3500","1500","1200","2200"};

    private int cart_icon = R.drawable.ic_cart;
    private int wishlist_icon = R.drawable.ic_heart;
    private ArrayList<Testproduct> mArraylist = new ArrayList<>();
    private MyRecyclerViewAdapter mMyRecyclerViewAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_food, container, false);
//        RecyclerView recyclerView = view.findViewById(R.id.food_recycler_view);
//        mMyRecyclerViewAdapter=new MyRecyclerViewAdapter(getActivity(),mArraylist);
//        PopulateRecyclerView populateRecyclerView =
//                new PopulateRecyclerView(productNames, productPrices, productImages, productDescription
//                        , cart_icon, wishlist_icon, mArraylist, mMyRecyclerViewAdapter);
//
//        populateRecyclerView.populate();
//
//        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 2));
//        recyclerView.setAdapter(mMyRecyclerViewAdapter);

        return view;
    }

}

