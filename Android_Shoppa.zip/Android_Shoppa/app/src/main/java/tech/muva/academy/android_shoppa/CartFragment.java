package tech.muva.academy.android_shoppa;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class CartFragment extends Fragment {


    public CartFragment() {
        // Required empty public constructor
    }

    private String[] productNames = {"Hp Laptop","Cubot phone","Hover Board",
            "Mouse","Beat wireless earphones","Keyboard","X-box"
    };
    private int[] productImages = {R.drawable.hp_laptop,R.drawable.cubot_phone,R.drawable.hover_board,
            R.drawable.mouse,R.drawable.beat_headphones,R.drawable.keyboard,R.drawable.xbox};
    private String[] productPrices = {"17000","800","1500","3500","1500","1200","2200"};
    private ArrayList<Product> mProductArrayList = new ArrayList<>();
    private CartRecyclerAdapter mCartRecyclerAdapter = new
            CartRecyclerAdapter(getActivity(),mProductArrayList);

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View view = inflater.inflate(R.layout.fragment_cart, container, false);
       RecyclerView recyclerView = view.findViewById(R.id.cart_recycler_view);

       populateCartRecyclerView();

       recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
       recyclerView.setAdapter(mCartRecyclerAdapter);
       return view;
    }

    private void populateCartRecyclerView() {

       mProductArrayList.clear();

        for(int index=0; index<productNames.length;index++){
            Product product = new Product();
            product.setName(productNames[index]);
            product.setPrice(productPrices[index]);
            product.setImage(productImages[index]);

            mProductArrayList.add(product);
        }
        mCartRecyclerAdapter.notifyDataSetChanged();
    }


}
