package tech.muva.academy.android_shoppa;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class CartRecyclerAdapter extends RecyclerView.Adapter<CartRecyclerAdapter.ViewHolder> {
    private Context mContext;
    private LayoutInflater mInflater;
    private ArrayList<Product> mProductArrayList;

    public CartRecyclerAdapter(Context context, ArrayList<Product> productArrayList) {
        mContext = context;
        mProductArrayList = productArrayList;
    }

    @NonNull
    @Override
    public CartRecyclerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_cart, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Product product = mProductArrayList.get(position);
        holder.product_name.setText(product.getName());
        holder.product_price.setText(product.getPrice());
        holder.cart_image.setImageResource(product.getImage());

    }



    @Override
    public int getItemCount() {
        return mProductArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        CircleImageView cart_image;
        TextView product_name, product_price;
        Button btn_remove, btn_edit;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cart_image = itemView.findViewById(R.id.cart_image);
            product_name = itemView.findViewById(R.id.cart_product_name);
            product_price = itemView.findViewById(R.id.cart_product_price);
            btn_remove = itemView.findViewById(R.id.remove_product);
            btn_edit = itemView.findViewById(R.id.edit_quantity);
        }

        @Override
        public void onClick(View view) {

        }
    }
}
