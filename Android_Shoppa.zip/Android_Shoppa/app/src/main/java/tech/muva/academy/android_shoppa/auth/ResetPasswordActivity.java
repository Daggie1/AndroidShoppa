package tech.muva.academy.android_shoppa.auth;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import tech.muva.academy.android_shoppa.R;

public class ResetPasswordActivity extends AppCompatActivity  {

    ImageButton backButton;

    private static final String IS_CHANGE_PASSWORD ="tech.muva.academy.android_shoppa.auth.isChangepassword" ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(getIntent().getBooleanExtra(IS_CHANGE_PASSWORD,true)){
            setContentView(R.layout.activity_change_password);
        }else{
        setContentView(R.layout.activity_reset_password);
        }

        backButton = findViewById(R.id.back_to_login);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ResetPasswordActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
    }
    public  static  Intent startSelfIntent(Context context,boolean isChangePassword){
        Intent i=new Intent(context,ResetPasswordActivity.class);
        i.putExtra(IS_CHANGE_PASSWORD,isChangePassword);
        return i;
    }
}
