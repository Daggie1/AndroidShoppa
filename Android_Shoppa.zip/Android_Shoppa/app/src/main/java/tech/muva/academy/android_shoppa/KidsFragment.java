package tech.muva.academy.android_shoppa;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class KidsFragment extends Fragment {


    public KidsFragment() {
        // Required empty public constructor
    }
    private String[] productNames = {"Apron","Bed","Car",
            "Play house","Slide","Sneakers","Brown Rubber"
    };
    private String[] productDescription = {"Apron","Bed","Car",
            "Play house","Slide","Sneakers","Brown Rubber"
    };
    private int[] productImages = {R.drawable.kid_apron,R.drawable.kids_bed,R.drawable.kids_car,
            R.drawable.kids_playhouse,R.drawable.kids_slide,R.drawable.kids_sneakers,R.drawable.rubber_shoe};

    private String[] productPrices = {"17000","800","1500","3500","1500","1200","2200"};

    private int cart_icon = R.drawable.ic_cart;
    private int wishlist_icon = R.drawable.ic_heart;
    private ArrayList<Product> mArraylist = new ArrayList<>();
    private MyRecyclerViewAdapter mMyRecyclerViewAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_kids, container, false);
//        RecyclerView recyclerView = view.findViewById(R.id.kids_recycler_view);
//        mMyRecyclerViewAdapter=new MyRecyclerViewAdapter(getActivity(),mArraylist);
//        PopulateRecyclerView populateRecyclerView =
//                new PopulateRecyclerView(productNames, productPrices, productImages, productDescription
//                        , cart_icon, wishlist_icon, mArraylist, mMyRecyclerViewAdapter);
//        populateRecyclerView.populate();
//
//        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 2));
//        recyclerView.setAdapter(mMyRecyclerViewAdapter);
        return view;

    }

}

