package tech.muva.academy.android_shoppa;


import android.os.Parcel;
import android.os.Parcelable;

public class Product implements Parcelable {
    String category,name,price,strikedprice,description;
    int image, cart_icon, wishlist_icon;

    public Product() {
    }

    protected Product(Parcel in) {
        category = in.readString();
        name = in.readString();
        price = in.readString();
        strikedprice = in.readString();
        description = in.readString();
        image = in.readInt();
        cart_icon = in.readInt();
        wishlist_icon = in.readInt();
    }

    public static final Creator<Product> CREATOR = new Creator<Product>() {
        @Override
        public Product createFromParcel(Parcel in) {
            return new Product(in);
        }

        @Override
        public Product[] newArray(int size) {
            return new Product[size];
        }
    };


    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getStrikedprice() {
        return strikedprice;
    }

    public void setStrikedprice(String strikedprice) {
        this.strikedprice = strikedprice;
    }

    public int getCart_icon() {
        return cart_icon;
    }

    public void setCart_icon(int cart_icon) {
        this.cart_icon = cart_icon;
    }

    public int getWishlist_icon() {
        return wishlist_icon;
    }

    public void setWishlist_icon(int wishlist_icon) {
        this.wishlist_icon = wishlist_icon;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(category);
        dest.writeString(name);
        dest.writeString(price);
        dest.writeString(strikedprice);
        dest.writeString(description);
        dest.writeInt(image);
        dest.writeInt(cart_icon);
        dest.writeInt(wishlist_icon);
    }
}


