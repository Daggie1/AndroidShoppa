package tech.muva.academy.android_shoppa;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import io.objectbox.Box;
import io.objectbox.query.Query;
import io.objectbox.query.QueryBuilder;


public class AddProductActivity extends AppCompatActivity {
    public static List<Testproduct> mArrayList;
    private Query<Testproduct> mTest_productQuery;
    private List<Testproduct> mList;
    Box<Testproduct> productBox;
    Box<Testproduct> productbox2;
    TextView result;
    private Query<Testproduct> query2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);
        //Box<Product> notesBox = ObjectBox.get().boxFor(Product.class);


        productBox =ObjectBox.get().boxFor(Testproduct.class);
        productBox.removeAll();
        Testproduct p = new Testproduct("Electronics", "huawei",
                "2,000", "2,500", R.drawable.cinamon_toast, R.drawable.valentines_heart,
                R.drawable.cart);
        productBox.put(p);

        Button obtest = findViewById(R.id.object_box_test);
        result = findViewById(R.id.object_box_result);

        obtest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //getproduct();
                //getSpecificProduct();
                getAllProducts();
            }
        });

        productbox2 = ObjectBox.get().boxFor(Testproduct.class);
        Testproduct p3 = new Testproduct("Clothes","samsung",
                "2500","2750"
                ,R.drawable.cart,R.drawable.valentines_heart,R.drawable.cart);

        productbox2.put(p3);
        p3 = new Testproduct("Kids","bunkbed","3000","3250",
                R.drawable.kids_playhouse,R.drawable.valentines_heart, R.drawable.cart);
        productbox2.put(p3);
        p3 = new Testproduct("Food","Burger","750","850",
                R.drawable.burger,R.drawable.valentines_heart, R.drawable.cart);
        productbox2.put(p3);

    }

    private void getproduct(){
        mTest_productQuery = productBox.query().order(Testproduct_.__ID_PROPERTY).build();
        mList = mTest_productQuery.find();
        result.setText(mList.get(0).category);
    }

    private void getSpecificProduct(){
        QueryBuilder builder = productBox.query();
        builder.startsWith(Testproduct_.price,"3000");
        List<Testproduct> expensive = builder.build().find();

        result.setText(expensive.get(0).name);
    }

    public void getAllProducts(){
        QueryBuilder builder2 = productbox2.query();
        builder2.order(Testproduct_.__ID_PROPERTY);
        List<Testproduct> allproducts = builder2.build().find();

        for (int index=0; index<allproducts.size(); index++)
        {
            result.append(allproducts.get(index).category);
            result.append(" ");
        }
    }

}
